# Skeptical reviewer red-team

## R1 - CRITICAL-SCOPE
**Attack:** Cross-cancer holdout could be misread as glioma biological validation

**Disposition:** ADDRESSED

**Response:** Explicitly states LSCC tests generic RNA-protein ranking transport, not glioma-specific biology.

## R2 - MAJOR
**Attack:** rho~0.91 may look implausibly high/circular

**Disposition:** ADDRESSED

**Response:** Explains transparent same-gene rank construction and limits claim to cross-modal ordering, never flux.

## R3 - MAJOR
**Attack:** Phase18 molecular access began before parser repair

**Disposition:** ADDRESSED

**Response:** Selections frozen before access; no statistic ran; repair parser-only; forensic recomputation complete.

## R4 - MAJOR
**Attack:** n=89 only modestly exceeds required 85

**Disposition:** RETAINED

**Response:** Exact predeclared gate and evaluable n reported; no post-hoc power inflation.

## R5 - MAJOR
**Attack:** One patient has different primary-tumor samples by modality

**Disposition:** ADDRESSED

**Response:** Disclosed; excluding patient leaves rho~0.906 at n=88.

## R6 - MAJOR
**Attack:** OXPHOS positive adjusted p could be oversold

**Disposition:** ADDRESSED

**Response:** Kept unsupported because rho=0.280 < frozen 0.30 effect bar.

## R7 - MAJOR
**Attack:** 39 method tests are correlated, not 39 independent replications

**Disposition:** ADDRESSED

**Response:** Main limitations explicitly prohibit that interpretation.

## R8 - MAJOR
**Attack:** Two significant negative external method results undermine universality

**Disposition:** RETAINED_AS_RESULT

**Response:** Both named in main Results/Discussion and Fig3.

## R9 - MAJOR
**Attack:** Development scFEA/METAFlux serine results contradict direct methods

**Disposition:** RETAINED_AS_RESULT

**Response:** Both preserved in Results/Fig4.

## R10 - MAJOR
**Attack:** No affirmative spatial validation

**Disposition:** RETAINED_LIMITATION

**Response:** T4 remains NOT_ADMISSIBLE_FROZEN_COVERAGE; no substitute endpoint.

## R11 - MODERATE
**Attack:** Compass missing due Gurobi licensing

**Disposition:** RETAINED_LIMITATION

**Response:** Classified external-license dependency, not biological failure.

## R12 - MODERATE
**Attack:** VISION small-n incompatibility

**Disposition:** RETAINED_LIMITATION

**Response:** No fallback substitution.

## R13 - MODERATE
**Attack:** scCellFie citation is preprint

**Disposition:** ADDRESSED

**Response:** Explicitly labeled bioRxiv preprint.

## R14 - MAJOR-RESOURCE
**Attack:** Public v1.0.1 predates Phase15-22 external work

**Disposition:** PHASE23_BLOCKER

**Response:** Must publish a new immutable release before submission.

## R15 - MODERATE
**Attack:** Generative AI disclosure required

**Disposition:** ADDRESSED

**Response:** Specific Methods disclosure and human accountability.

## R16 - MAJOR-FIT
**Attack:** Could look like application of existing tools

**Disposition:** ADDRESSED

**Response:** Novelty framed as fail-closed benchmark/governance methodology and prespecified external architecture.

## R17 - MODERATE
**Attack:** RNA-protein concordance is not metabolic flux

**Disposition:** ADDRESSED

**Response:** Claim ceiling enforced throughout.

## R18 - MODERATE
**Attack:** Small n=3 development modules

**Disposition:** ADDRESSED

**Response:** Descriptive/exact-resolution limits explicit.

## Decision
No unresolved scientific blocker requires changing frozen results. The only hard pre-submission blocker is Phase 23 public-release/update packaging. Scientific retuning is prohibited.
