# Neuroinformatics compliance checklist - checked 18 August 2026

- PASS: Original Article framing emphasizes a benchmarking methodology and a prospectively frozen test, not simple application.
- PASS: title page includes author, affiliation, email, ORCID.
- PASS: abstract 150-250 words.
- PASS: 6 keywords.
- PASS: <=3 displayed heading levels.
- PASS: Information Sharing Statement immediately before Acknowledgments.
- PASS: Statements and Declarations included.
- PASS: generative-AI use documented in Methods with human accountability.
- PASS: editable LaTeX source included.
- PASS: figures numbered consecutively; captions outside image files.
- PASS: EPS/PDF/SVG vectors plus 600-dpi PNGs included.
- PASS: figure semantics use marker shape/line type, not color alone.
- PASS: author-year references and DOI links.
- PASS: supplementary full 39-test table included.
- PHASE23 REQUIRED: publish/version Phase15-22 reproducibility authority before submission and insert exact DOI/version.
- PHASE23 REQUIRED: final Springer-template/upload packaging and logged-out public DOI check.
